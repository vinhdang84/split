import React from "react";

class MealList extends React.Component {
  render() {
    return (
      <div>
        <h4>List of Meals</h4>
      </div>
    );
  }
}

export default MealList;
