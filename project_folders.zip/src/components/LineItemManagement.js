import React from "react";
import AddLineItem from "./AddLineItem";

class LineItemManagement extends React.Component {
  render() {
    return (
      <div>
        <h3> &emsp;Line Item Management</h3>
        <AddLineItem addLineItem={this.props.addLineItem} friends={this.props.friends} />
      </div>
    );
  }
}

export default LineItemManagement;
