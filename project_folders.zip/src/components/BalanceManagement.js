import React from "react";

class BalanceManagement extends React.Component {
  render() {
    return (
      <div>
        <h3>&emsp;Balance Management</h3>
      </div>
    );
  }
}

export default BalanceManagement;
